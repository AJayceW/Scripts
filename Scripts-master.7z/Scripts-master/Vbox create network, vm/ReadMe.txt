These scripts will create a virtualbox host network, and a virtual machine

Requirements:
    Have VirtualBox installed
    Have vboxmanage added to environment variable
    expects CentOS-7-x86_64-Minimal-1810.iso to be in /isos folder which should be located in same path as this readme
    expects VBoxGuestAdditions.iso to be in /isos folder