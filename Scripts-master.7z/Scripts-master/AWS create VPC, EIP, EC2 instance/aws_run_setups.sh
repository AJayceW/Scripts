./aws_cli_vpc_setup.sh
./aws_cli_eip_setup.sh
./aws_cli_ec2_setup.sh