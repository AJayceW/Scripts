These scripts will create an AWS VPC, elastic IP, and EC2 instance.
Uses aws_run_setups.sh to run all the scripts

Requirements:
    replace the values for the declarations in aws_cli_vpc_setup.sh
    replace the values for the declarations in aws_cli_ec2_setup.sh
    a key.pem from AWS