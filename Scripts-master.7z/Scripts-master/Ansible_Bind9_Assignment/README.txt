Instructions:
Change IP in hosts file to host IP
Change username in hosts file
Change IP in named.conf.local file to host

Set up client's named.local if planning to have slave


Not fully finished